package hdfs;



import java.io.IOException;
import java.io.PrintStream;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;

public class FileModifiedTime {
	static long startTs;
	static long endTs;
	
	public static void main(String[] args) {
		if (args.length != 3) {
			System.out.println("Pass 3 arguments");
			System.exit(1);
		}
		startTs = Long.parseLong(args[1]);
		endTs = Long.parseLong(args[2]);
		getStatus(new Path(args[0]));
		
	}
	
	public static void getStatus(Path path) {
		try
		{
			Configuration conf = new Configuration();
			FileSystem fileSystem = FileSystem.get(path.toUri(), conf);
			FileStatus[] fileStatus=fileSystem.listStatus(path);
			
			for (FileStatus fStat : fileStatus) {
				if (fStat.isDirectory()) {
					System.out.println("Directory: " + fStat.getPath());
					getStatus(fStat.getPath());
				}
				else if (fStat.isFile()) {
					long modifiedTIme = fStat.getModificationTime();
					//System.out.println("Modified Time : " + modifiedTIme);
					if((startTs < modifiedTIme) && (modifiedTIme <= endTs))
						System.out.println("File: " + fStat.getPath()+ "\t Modified Time : " +  modifiedTIme);
					
				}
				else if (fStat.isSymlink()) {
					long modifiedTIme = fStat.getModificationTime();
					//System.out.println("Modified Time : " + modifiedTIme);
					if((startTs < modifiedTIme) && (modifiedTIme <= endTs))
					System.out.println("Symlink: " + fStat.getPath());
				}
			}

		}
		catch (IOException e)
		{
            e.printStackTrace();
		}
	}
}